﻿Public Class frmScoring

    Private Sub TblScoresBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.TblScoresBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TriviaDataSet)

    End Sub

    Private Sub frmScoring_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        FilterScores()
    End Sub

    Private Sub frmScoring_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Me.Validate()
        Me.TblScoresBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TriviaDataSet)
    End Sub

    Private Sub frmScoring_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TriviaDataSet.tblRounds1' table. You can move, or remove it, as needed.
        Me.TblRounds1TableAdapter.Fill(Me.TriviaDataSet.tblRounds1)
        'TODO: This line of code loads data into the 'TriviaDataSet.tblRounds' table. You can move, or remove it, as needed.
        Me.TblRoundsTableAdapter.Fill(Me.TriviaDataSet.tblRounds)
        'TODO: This line of code loads data into the 'TriviaDataSet.tblTeams' table. You can move, or remove it, as needed.
        Me.TblTeamsTableAdapter.Fill(Me.TriviaDataSet.tblTeams)
        'TODO: This line of code loads data into the 'TriviaDataSet.tblScores' table. You can move, or remove it, as needed.
        Me.TblScoresTableAdapter.Fill(Me.TriviaDataSet.tblScores)

    End Sub
    Private Sub FilterScores()
        Me.Validate()
        Me.TblScoresBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TriviaDataSet)
        Dim var1 As String = lbxRounds.SelectedValue
        Dim var2 As Integer = lbxTeams.SelectedValue
        Dim strFilter As String = "TeamUID = " & var2 & " and Round = '" & var1 & "'"
        Me.TblScoresBindingSource.Filter = strFilter

        UpdateScore()
    End Sub

    Private Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        FilterScores()
    End Sub

    Private Sub TblScoresBindingSource_ListChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ListChangedEventArgs) Handles TblScoresBindingSource.ListChanged
        Me.Validate()
        Me.TblScoresBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TriviaDataSet)
    End Sub

    Private Sub TblRounds1BindingSource_ListChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ListChangedEventArgs) Handles TblRounds1BindingSource.ListChanged
        FilterScores()
    End Sub

    Private Sub TblTeamsBindingSource_ListChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ListChangedEventArgs) Handles TblTeamsBindingSource.ListChanged
        FilterScores()
    End Sub

    Private Sub lbxRounds_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbxRounds.SelectedValueChanged
        FilterScores()
    End Sub

    Private Sub lbxTeams_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbxTeams.SelectedValueChanged
        FilterScores()
    End Sub
    Private Sub frmScores_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown

        If (e.KeyCode >= 48 And e.KeyCode <= 57) Or (e.KeyCode >= 96 And e.KeyCode <= 105) Or e.KeyCode = 107 Or e.KeyCode = 110 Then
            Dim myAction As Integer
            If e.Control Then
                myAction = 1 'change to not correct
            ElseIf e.Alt Then
                myAction = 2 'change to correct and mulligan
            Else
                myAction = 3 'change to correct
            End If

            Dim myKey As Integer
            Select Case CInt(e.KeyValue.ToString)
                Case 49, 97
                    myKey = 1
                Case 50, 98
                    myKey = 2
                Case 51, 99
                    myKey = 3
                Case 52, 100
                    myKey = 4
                Case 53, 101
                    myKey = 5
                Case 54, 102
                    myKey = 6
                Case 55, 103
                    myKey = 7
                Case 56, 104
                    myKey = 8
                Case 57, 105
                    myKey = 9
                Case 48, 96
                    myKey = 0
                Case 107
                    ChangeAllAnswers(lbxTeams.SelectedValue, lbxRounds.SelectedValue)
                    Me.TblScoresTableAdapter.Fill(Me.TriviaDataSet.tblScores)
                    GoTo Skip
                Case 110
                    ClearAllAnswers(lbxTeams.SelectedValue, lbxRounds.SelectedValue)
                    Me.TblScoresTableAdapter.Fill(Me.TriviaDataSet.tblScores)
                    GoTo Skip
            End Select

            'calculate proper question number
            Select Case myKey
                Case 0
                    myKey = myKey + ((lbxRounds.SelectedValue - 1) * 10) + 10
                Case Else
                    myKey = myKey + ((lbxRounds.SelectedValue - 1) * 10)
            End Select

            'update score
            Select Case myAction
                Case 2
                    ChangeAnswer(lbxTeams.SelectedValue, lbxRounds.SelectedValue, myKey, True, True)
                Case 1
                    ChangeAnswer(lbxTeams.SelectedValue, lbxRounds.SelectedValue, myKey, False, False)
                Case 3
                    ChangeAnswer(lbxTeams.SelectedValue, lbxRounds.SelectedValue, myKey, True, False)
            End Select

            'reload data to show changes
            Me.TblScoresTableAdapter.Fill(Me.TriviaDataSet.tblScores)
            e.SuppressKeyPress = True
        End If
Skip:
    End Sub


    Public Sub ChangeAnswer(myTeam As Integer, myRound As Integer, myQuestion As Integer, myScore As Boolean, myMulligan As Boolean)

        Dim SQLCon As New SqlClient.SqlConnection
        Dim SQLCmd As New SqlClient.SqlCommand
        SQLCon.ConnectionString = My.Settings.TriviaConnectionString2.ToString
        SQLCon.Open()
        SQLCmd.CommandText = "update tblscores set tblscores.correct=@correct, tblscores.mulligan=@mulligan where tblscores.teamUID = @teamUID and tblscores.Question=@question and tblscores.Round = @round"
        SQLCmd.CommandType = CommandType.Text 'Setup Command Type
        SQLCmd.Connection = SQLCon 'Active Connection


        SQLCmd.Parameters.AddWithValue("@teamUID", lbxTeams.SelectedValue)
        SQLCmd.Parameters.AddWithValue("@round", lbxRounds.SelectedValue)
        SQLCmd.Parameters.AddWithValue("@question", myQuestion)
        SQLCmd.Parameters.AddWithValue("@correct", myScore)
        SQLCmd.Parameters.AddWithValue("@mulligan", myMulligan)

        SQLCmd.ExecuteNonQuery() 'We are executing the procedure here by calling Execute Non Query.

        SQLCon.Close()
    End Sub
    Public Sub ClearAllAnswers(myTeam As Integer, myRound As Integer)

        Dim SQLCon As New SqlClient.SqlConnection
        Dim SQLCmd As New SqlClient.SqlCommand
        SQLCon.ConnectionString = My.Settings.TriviaConnectionString2.ToString
        SQLCon.Open()
        SQLCmd.CommandText = "update tblscores set tblscores.correct=0, tblscores.mulligan=0 where tblscores.teamUID = @teamUID and tblscores.Round = @round"
        SQLCmd.CommandType = CommandType.Text 'Setup Command Type
        SQLCmd.Connection = SQLCon 'Active Connection


        SQLCmd.Parameters.AddWithValue("@teamUID", lbxTeams.SelectedValue)
        SQLCmd.Parameters.AddWithValue("@round", lbxRounds.SelectedValue)

        SQLCmd.ExecuteNonQuery() 'We are executing the procedure here by calling Execute Non Query.

        SQLCon.Close()
    End Sub

    Public Sub ChangeAllAnswers(myTeam As Integer, myRound As Integer)

        Dim SQLCon As New SqlClient.SqlConnection
        Dim SQLCmd As New SqlClient.SqlCommand
        SQLCon.ConnectionString = My.Settings.TriviaConnectionString2.ToString
        SQLCon.Open()
        SQLCmd.CommandText = "update tblscores set tblscores.correct=1, tblscores.mulligan=0 where tblscores.teamUID = @teamUID and tblscores.Round = @round"
        SQLCmd.CommandType = CommandType.Text 'Setup Command Type
        SQLCmd.Connection = SQLCon 'Active Connection


        SQLCmd.Parameters.AddWithValue("@teamUID", lbxTeams.SelectedValue)
        SQLCmd.Parameters.AddWithValue("@round", lbxRounds.SelectedValue)

        SQLCmd.ExecuteNonQuery() 'We are executing the procedure here by calling Execute Non Query.

        SQLCon.Close()
    End Sub
    Private Sub UpdateScore()
        ''Set up Connection object and Connection String for a SQL Client
        'Dim SQLCon As New SqlClient.SqlConnection
        'Dim SQLCmd As New SqlClient.SqlCommand
        'SQLCon.ConnectionString = My.Settings.TriviaConnectionString1.ToString

        'SQLCon.Open()

        'SQLCmd.CommandText = "RoundScoreByTeam"
        'SQLCmd.CommandType = CommandType.StoredProcedure 'Setup Command Type
        'SQLCmd.Connection = SQLCon 'Active Connection


        'SQLCmd.Parameters.AddWithValue("@teamUID", 5)
        'SQLCmd.Parameters.AddWithValue("@round", 1)
        'SQLCmd.Parameters.AddWithValue("@TotalRoundScore", "")
        'SQLCmd.Parameters("@TotalRoundScore").Direction = ParameterDirection.Output
        'SQLCmd.Parameters("@TotalRoundScore").SqlDbType = SqlDbType.Int

        'SQLCmd.ExecuteNonQuery() 'We are executing the procedure here by calling Execute Non Query.

        'Me.lblRoundScore.Text = SQLCmd.Parameters("@TotalRoundScore").Value
        'SQLCon.Close()
    End Sub
End Class