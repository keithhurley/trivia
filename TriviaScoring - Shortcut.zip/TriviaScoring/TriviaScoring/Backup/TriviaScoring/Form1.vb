﻿Public Class Form1

    Private Sub TblTeamsBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.TblTeamsBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TriviaDataSet)

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TriviaDataSet.tblTeams' table. You can move, or remove it, as needed.
        Me.TblTeamsTableAdapter.Fill(Me.TriviaDataSet.tblTeams)

    End Sub
End Class
