﻿Public Class frmMain

    Private Sub LinkLabel1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkLabel1.Click
        Dim frmForm As New frmTeams
        frmForm.ShowDialog()

    End Sub

    Private Sub LinkLabel2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkLabel2.Click
        Dim frmForm As New frmScores
        frmForm.ShowDialog()

    End Sub
End Class