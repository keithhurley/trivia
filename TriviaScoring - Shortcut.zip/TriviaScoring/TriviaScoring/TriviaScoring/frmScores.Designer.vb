﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmScores
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.TriviaDataSet = New TriviaScoring.TriviaDataSet()
        Me.TblScoresBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblScoresTableAdapter = New TriviaScoring.TriviaDataSetTableAdapters.tblScoresTableAdapter()
        Me.TableAdapterManager = New TriviaScoring.TriviaDataSetTableAdapters.TableAdapterManager()
        Me.TblTeams1TableAdapter = New TriviaScoring.TriviaDataSetTableAdapters.tblTeams1TableAdapter()
        Me.lbxTeams = New System.Windows.Forms.ListBox()
        Me.TblTeams1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.lbxRounds = New System.Windows.Forms.ListBox()
        Me.lblRoundScore = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Round_Number = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewCheckBoxColumn3 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.DataGridViewCheckBoxColumn4 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.TblRounds1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblRounds1TableAdapter = New TriviaScoring.TriviaDataSetTableAdapters.tblRounds1TableAdapter()
        CType(Me.TriviaDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblScoresBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTeams1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblRounds1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TriviaDataSet
        '
        Me.TriviaDataSet.DataSetName = "TriviaDataSet"
        Me.TriviaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblScoresBindingSource
        '
        Me.TblScoresBindingSource.DataMember = "tblScores"
        Me.TblScoresBindingSource.DataSource = Me.TriviaDataSet
        '
        'TblScoresTableAdapter
        '
        Me.TblScoresTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.tblRoundsTableAdapter = Nothing
        Me.TableAdapterManager.tblScoresTableAdapter = Me.TblScoresTableAdapter
        Me.TableAdapterManager.tblTeams1TableAdapter = Me.TblTeams1TableAdapter
        Me.TableAdapterManager.tblTeamsTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = TriviaScoring.TriviaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'TblTeams1TableAdapter
        '
        Me.TblTeams1TableAdapter.ClearBeforeFill = True
        '
        'lbxTeams
        '
        Me.lbxTeams.DataSource = Me.TblTeams1BindingSource
        Me.lbxTeams.DisplayMember = "Team_Name"
        Me.lbxTeams.FormattingEnabled = True
        Me.lbxTeams.Location = New System.Drawing.Point(12, 139)
        Me.lbxTeams.Name = "lbxTeams"
        Me.lbxTeams.Size = New System.Drawing.Size(148, 277)
        Me.lbxTeams.TabIndex = 4
        Me.lbxTeams.ValueMember = "UID"
        '
        'TblTeams1BindingSource
        '
        Me.TblTeams1BindingSource.DataMember = "tblTeams1"
        Me.TblTeams1BindingSource.DataSource = Me.TriviaDataSet
        '
        'lbxRounds
        '
        Me.lbxRounds.DataSource = Me.TblRounds1BindingSource
        Me.lbxRounds.DisplayMember = "Round_Number"
        Me.lbxRounds.FormattingEnabled = True
        Me.lbxRounds.Location = New System.Drawing.Point(12, 5)
        Me.lbxRounds.Name = "lbxRounds"
        Me.lbxRounds.Size = New System.Drawing.Size(148, 121)
        Me.lbxRounds.TabIndex = 5
        Me.lbxRounds.ValueMember = "Round_Number"
        '
        'lblRoundScore
        '
        Me.lblRoundScore.Location = New System.Drawing.Point(265, 390)
        Me.lblRoundScore.Name = "lblRoundScore"
        Me.lblRoundScore.Size = New System.Drawing.Size(181, 26)
        Me.lblRoundScore.TabIndex = 6
        Me.lblRoundScore.Text = "Label1"
        Me.lblRoundScore.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(169, 390)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(81, 26)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "Update Score"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Round_Number
        '
        Me.Round_Number.DataPropertyName = "Round"
        Me.Round_Number.HeaderText = "Round_Number"
        Me.Round_Number.Name = "Round_Number"
        Me.Round_Number.Visible = False
        Me.Round_Number.Width = 88
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.MenuBar
        Me.DataGridView1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.MenuBar
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn5, Me.Round_Number, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewCheckBoxColumn3, Me.DataGridViewCheckBoxColumn4})
        Me.DataGridView1.DataSource = Me.TblScoresBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(177, 5)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DataGridView1.RowHeadersVisible = False
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.InactiveCaption
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.DataGridView1.Size = New System.Drawing.Size(178, 379)
        Me.DataGridView1.TabIndex = 3
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "UID"
        Me.DataGridViewTextBoxColumn5.HeaderText = "UID"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Visible = False
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "TeamUID"
        Me.DataGridViewTextBoxColumn6.HeaderText = "TeamUID"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Visible = False
        Me.DataGridViewTextBoxColumn6.Width = 59
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "Question"
        Me.DataGridViewTextBoxColumn7.HeaderText = "Question"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Width = 74
        '
        'DataGridViewCheckBoxColumn3
        '
        Me.DataGridViewCheckBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.DataGridViewCheckBoxColumn3.DataPropertyName = "Correct"
        Me.DataGridViewCheckBoxColumn3.HeaderText = "Correct"
        Me.DataGridViewCheckBoxColumn3.Name = "DataGridViewCheckBoxColumn3"
        Me.DataGridViewCheckBoxColumn3.Width = 47
        '
        'DataGridViewCheckBoxColumn4
        '
        Me.DataGridViewCheckBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.DataGridViewCheckBoxColumn4.DataPropertyName = "Mulligan"
        Me.DataGridViewCheckBoxColumn4.HeaderText = "Mulligan"
        Me.DataGridViewCheckBoxColumn4.Name = "DataGridViewCheckBoxColumn4"
        Me.DataGridViewCheckBoxColumn4.Width = 52
        '
        'TblRounds1BindingSource
        '
        Me.TblRounds1BindingSource.DataMember = "tblRounds1"
        Me.TblRounds1BindingSource.DataSource = Me.TriviaDataSet
        '
        'TblRounds1TableAdapter
        '
        Me.TblRounds1TableAdapter.ClearBeforeFill = True
        '
        'frmScores
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(466, 436)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lblRoundScore)
        Me.Controls.Add(Me.lbxRounds)
        Me.Controls.Add(Me.lbxTeams)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "frmScores"
        Me.Text = "Scores"
        CType(Me.TriviaDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblScoresBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTeams1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblRounds1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TriviaDataSet As TriviaScoring.TriviaDataSet
    Friend WithEvents TblScoresBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblScoresTableAdapter As TriviaScoring.TriviaDataSetTableAdapters.tblScoresTableAdapter
    Friend WithEvents TableAdapterManager As TriviaScoring.TriviaDataSetTableAdapters.TableAdapterManager
    Friend WithEvents lbxTeams As System.Windows.Forms.ListBox
    Friend WithEvents lbxRounds As System.Windows.Forms.ListBox
    Friend WithEvents lblRoundScore As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Round_Number As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn3 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn4 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents TblTeams1BindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTeams1TableAdapter As TriviaScoring.TriviaDataSetTableAdapters.tblTeams1TableAdapter
    Friend WithEvents TblRounds1BindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblRounds1TableAdapter As TriviaScoring.TriviaDataSetTableAdapters.tblRounds1TableAdapter
End Class
