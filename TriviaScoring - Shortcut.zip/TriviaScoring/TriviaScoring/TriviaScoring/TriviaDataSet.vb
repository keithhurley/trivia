﻿Partial Class TriviaDataSet
End Class

Namespace TriviaDataSetTableAdapters
    
    Partial Public Class tblTeams1TableAdapter
    End Class
End Namespace
