﻿Public Class frmTeams

    Private Sub TblTeamsBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.TblTeamsBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TriviaDataSet)

    End Sub

    Private Sub frmTeams_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TriviaDataSet.tblTeams' table. You can move, or remove it, as needed.
        Me.TblTeamsTableAdapter.Fill(Me.TriviaDataSet.tblTeams)
        'TODO: This line of code loads data into the 'TriviaDataSet.tblTeams' table. You can move, or remove it, as needed.
        Me.TblTeamsTableAdapter.Fill(Me.TriviaDataSet.tblTeams)

    End Sub

    Private Sub TblTeamsBindingNavigatorSaveItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.TblTeamsBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TriviaDataSet)

    End Sub

    Private Sub TblTeamsBindingSource_ListChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ListChangedEventArgs) Handles TblTeamsBindingSource.ListChanged
        Me.TableAdapterManager.UpdateAll(Me.TriviaDataSet)
        Me.Label1.Text = Me.TblTeamsBindingSource.Count & " teams"


    End Sub

    Private Sub TblTeamsDataGridView_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles TblTeamsDataGridView.CellContentClick

    End Sub
End Class