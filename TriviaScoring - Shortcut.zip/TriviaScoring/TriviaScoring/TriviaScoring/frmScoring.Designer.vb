﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmScoring
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.TriviaDataSet = New TriviaScoring.TriviaDataSet()
        Me.TblScoresBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblScoresTableAdapter = New TriviaScoring.TriviaDataSetTableAdapters.tblScoresTableAdapter()
        Me.TableAdapterManager = New TriviaScoring.TriviaDataSetTableAdapters.TableAdapterManager()
        Me.TblRoundsTableAdapter = New TriviaScoring.TriviaDataSetTableAdapters.tblRoundsTableAdapter()
        Me.TblTeamsTableAdapter = New TriviaScoring.TriviaDataSetTableAdapters.tblTeamsTableAdapter()
        Me.TblScoresDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Round_Number = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewCheckBoxColumn1 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.DataGridViewCheckBoxColumn2 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.TblTeamsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.lbxTeams = New System.Windows.Forms.ListBox()
        Me.lbxRounds = New System.Windows.Forms.ListBox()
        Me.TblRounds1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblRoundsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblRounds1TableAdapter = New TriviaScoring.TriviaDataSetTableAdapters.tblRounds1TableAdapter()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lblRoundScore = New System.Windows.Forms.Label()
        CType(Me.TriviaDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblScoresBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblScoresDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTeamsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblRounds1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblRoundsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TriviaDataSet
        '
        Me.TriviaDataSet.DataSetName = "TriviaDataSet"
        Me.TriviaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblScoresBindingSource
        '
        Me.TblScoresBindingSource.DataMember = "tblScores"
        Me.TblScoresBindingSource.DataSource = Me.TriviaDataSet
        Me.TblScoresBindingSource.Filter = ""
        '
        'TblScoresTableAdapter
        '
        Me.TblScoresTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.tblRoundsTableAdapter = Me.TblRoundsTableAdapter
        Me.TableAdapterManager.tblScoresTableAdapter = Me.TblScoresTableAdapter
        Me.TableAdapterManager.tblTeamsTableAdapter = Me.TblTeamsTableAdapter
        Me.TableAdapterManager.UpdateOrder = TriviaScoring.TriviaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'TblRoundsTableAdapter
        '
        Me.TblRoundsTableAdapter.ClearBeforeFill = True
        '
        'TblTeamsTableAdapter
        '
        Me.TblTeamsTableAdapter.ClearBeforeFill = True
        '
        'TblScoresDataGridView
        '
        Me.TblScoresDataGridView.AllowUserToAddRows = False
        Me.TblScoresDataGridView.AllowUserToDeleteRows = False
        Me.TblScoresDataGridView.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.MenuBar
        Me.TblScoresDataGridView.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.TblScoresDataGridView.AutoGenerateColumns = False
        Me.TblScoresDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.TblScoresDataGridView.BackgroundColor = System.Drawing.SystemColors.MenuBar
        Me.TblScoresDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TblScoresDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        Me.TblScoresDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.TblScoresDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblScoresDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.Round_Number, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewCheckBoxColumn1, Me.DataGridViewCheckBoxColumn2})
        Me.TblScoresDataGridView.DataSource = Me.TblScoresBindingSource
        Me.TblScoresDataGridView.Location = New System.Drawing.Point(202, 12)
        Me.TblScoresDataGridView.MultiSelect = False
        Me.TblScoresDataGridView.Name = "TblScoresDataGridView"
        Me.TblScoresDataGridView.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.TblScoresDataGridView.RowHeadersVisible = False
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.InactiveCaption
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TblScoresDataGridView.RowsDefaultCellStyle = DataGridViewCellStyle2
        Me.TblScoresDataGridView.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.TblScoresDataGridView.Size = New System.Drawing.Size(178, 379)
        Me.TblScoresDataGridView.TabIndex = 1
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "UID"
        Me.DataGridViewTextBoxColumn1.HeaderText = "UID"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Visible = False
        '
        'Round_Number
        '
        Me.Round_Number.DataPropertyName = "Round"
        Me.Round_Number.HeaderText = "Round_Number"
        Me.Round_Number.Name = "Round_Number"
        Me.Round_Number.Visible = False
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "TeamUID"
        Me.DataGridViewTextBoxColumn2.HeaderText = "TeamUID"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Visible = False
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Question"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Question"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Width = 74
        '
        'DataGridViewCheckBoxColumn1
        '
        Me.DataGridViewCheckBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.DataGridViewCheckBoxColumn1.DataPropertyName = "Correct"
        Me.DataGridViewCheckBoxColumn1.HeaderText = "Correct"
        Me.DataGridViewCheckBoxColumn1.Name = "DataGridViewCheckBoxColumn1"
        Me.DataGridViewCheckBoxColumn1.Width = 47
        '
        'DataGridViewCheckBoxColumn2
        '
        Me.DataGridViewCheckBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.DataGridViewCheckBoxColumn2.DataPropertyName = "Mulligan"
        Me.DataGridViewCheckBoxColumn2.HeaderText = "Mulligan"
        Me.DataGridViewCheckBoxColumn2.Name = "DataGridViewCheckBoxColumn2"
        Me.DataGridViewCheckBoxColumn2.Width = 52
        '
        'TblTeamsBindingSource
        '
        Me.TblTeamsBindingSource.DataMember = "tblTeams"
        Me.TblTeamsBindingSource.DataSource = Me.TriviaDataSet
        '
        'lbxTeams
        '
        Me.lbxTeams.DataSource = Me.TblTeamsBindingSource
        Me.lbxTeams.DisplayMember = "Team_Name"
        Me.lbxTeams.FormattingEnabled = True
        Me.lbxTeams.Location = New System.Drawing.Point(12, 139)
        Me.lbxTeams.Name = "lbxTeams"
        Me.lbxTeams.Size = New System.Drawing.Size(148, 277)
        Me.lbxTeams.TabIndex = 2
        Me.lbxTeams.ValueMember = "UID"
        '
        'lbxRounds
        '
        Me.lbxRounds.DataSource = Me.TblRounds1BindingSource
        Me.lbxRounds.DisplayMember = "Round_Number"
        Me.lbxRounds.FormattingEnabled = True
        Me.lbxRounds.Location = New System.Drawing.Point(12, 12)
        Me.lbxRounds.Name = "lbxRounds"
        Me.lbxRounds.Size = New System.Drawing.Size(148, 121)
        Me.lbxRounds.TabIndex = 3
        Me.lbxRounds.ValueMember = "Round_Number"
        '
        'TblRounds1BindingSource
        '
        Me.TblRounds1BindingSource.DataMember = "tblRounds1"
        Me.TblRounds1BindingSource.DataSource = Me.TriviaDataSet
        '
        'TblRoundsBindingSource
        '
        Me.TblRoundsBindingSource.DataMember = "tblRounds"
        Me.TblRoundsBindingSource.DataSource = Me.TriviaDataSet
        '
        'TblRounds1TableAdapter
        '
        Me.TblRounds1TableAdapter.ClearBeforeFill = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(162, 55)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(19, 108)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'lblRoundScore
        '
        Me.lblRoundScore.AutoSize = True
        Me.lblRoundScore.Location = New System.Drawing.Point(353, 405)
        Me.lblRoundScore.Name = "lblRoundScore"
        Me.lblRoundScore.Size = New System.Drawing.Size(39, 13)
        Me.lblRoundScore.TabIndex = 5
        Me.lblRoundScore.Text = "Label1"
        '
        'frmScoring
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(404, 427)
        Me.Controls.Add(Me.lblRoundScore)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lbxRounds)
        Me.Controls.Add(Me.lbxTeams)
        Me.Controls.Add(Me.TblScoresDataGridView)
        Me.Name = "frmScoring"
        Me.Text = "frmScoring"
        CType(Me.TriviaDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblScoresBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblScoresDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTeamsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblRounds1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblRoundsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TriviaDataSet As TriviaScoring.TriviaDataSet
    Friend WithEvents TblScoresBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblScoresTableAdapter As TriviaScoring.TriviaDataSetTableAdapters.tblScoresTableAdapter
    Friend WithEvents TableAdapterManager As TriviaScoring.TriviaDataSetTableAdapters.TableAdapterManager
    Friend WithEvents TblTeamsTableAdapter As TriviaScoring.TriviaDataSetTableAdapters.tblTeamsTableAdapter
    Friend WithEvents TblScoresDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblTeamsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents lbxTeams As System.Windows.Forms.ListBox
    Friend WithEvents lbxRounds As System.Windows.Forms.ListBox
    Friend WithEvents TblRoundsTableAdapter As TriviaScoring.TriviaDataSetTableAdapters.tblRoundsTableAdapter
    Friend WithEvents TblRoundsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblRounds1BindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblRounds1TableAdapter As TriviaScoring.TriviaDataSetTableAdapters.tblRounds1TableAdapter
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Round_Number As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn1 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn2 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents lblRoundScore As System.Windows.Forms.Label
End Class
