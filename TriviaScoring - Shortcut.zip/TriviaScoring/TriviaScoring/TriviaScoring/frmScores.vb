﻿Public Class frmScores

    Private Sub TblScoresBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.TblScoresBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TriviaDataSet)

    End Sub

    'Private Sub frmScores_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
    '    FilterScores()
    'End Sub

    Private Sub FilterScores()
        Me.Validate()
        Me.TblScoresBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TriviaDataSet)
        Dim var1 As String = lbxRounds.SelectedValue
        Dim var2 As Integer = lbxTeams.SelectedValue
        Dim strFilter As String = "TeamUID = " & var2 & " and Round = '" & var1 & "'"
        Me.TblScoresBindingSource.Filter = strFilter

        UpdateScore()
    End Sub

    Private Sub frmScores_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Me.Validate()
        Me.TblScoresBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TriviaDataSet)
    End Sub

    Private Sub frmScores_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TriviaDataSet.tblRounds1' table. You can move, or remove it, as needed.
        Me.TblRounds1TableAdapter.Fill(Me.TriviaDataSet.tblRounds1)
        'TODO: This line of code loads data into the 'TriviaDataSet.tblScores' table. You can move, or remove it, as needed.
        Me.TblScoresTableAdapter.Fill(Me.TriviaDataSet.tblScores)
        'TODO: This line of code loads data into the 'TriviaDataSet.tblTeams1' table. You can move, or remove it, as needed.
        Me.TblTeams1TableAdapter.Fill(Me.TriviaDataSet.tblTeams1)



    End Sub

    'Private Sub TblRounds1BindingSource_ListChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ListChangedEventArgs) Handles TblRounds1BindingSource.ListChanged
    '    FilterScores()
    'End Sub

    'Private Sub TblTeams1BindingSource_ListChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ListChangedEventArgs) Handles TblTeams1BindingSource.ListChanged
    '    FilterScores()
    'End Sub
    Private Sub lbxRounds_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbxRounds.SelectedValueChanged
        FilterScores()
    End Sub

    Private Sub lbxTeams_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbxTeams.SelectedValueChanged
        FilterScores()
    End Sub
    Private Sub UpdateScore()
        On Error Resume Next
        'Set up Connection object and Connection String for a SQL Client
        Dim SQLCon As New SqlClient.SqlConnection
        Dim SQLCmd As New SqlClient.SqlCommand
        SQLCon.ConnectionString = My.Settings.TriviaConnectionString2.ToString

        SQLCon.Open()

        SQLCmd.CommandText = "RoundScoreByTeam"
        SQLCmd.CommandType = CommandType.StoredProcedure 'Setup Command Type
        SQLCmd.Connection = SQLCon 'Active Connection


        SQLCmd.Parameters.AddWithValue("@teamUID", lbxTeams.SelectedValue)
        SQLCmd.Parameters.AddWithValue("@round", lbxRounds.SelectedValue)
        SQLCmd.Parameters.AddWithValue("@TotalRoundScore", "")
        SQLCmd.Parameters("@TotalRoundScore").Direction = ParameterDirection.Output
        SQLCmd.Parameters("@TotalRoundScore").SqlDbType = SqlDbType.Int

        SQLCmd.ExecuteNonQuery() 'We are executing the procedure here by calling Execute Non Query.

        Me.lblRoundScore.Text = "Score For Round = " & CStr(SQLCmd.Parameters("@TotalRoundScore").Value.ToString)
        SQLCon.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        UpdateScore()
    End Sub

    Private Sub TblScoresBindingSource_ListChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ListChangedEventArgs) Handles TblScoresBindingSource.ListChanged
        Me.Validate()
        Me.TblScoresBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TriviaDataSet)
        UpdateScore()
    End Sub

    Private Sub DataGridView1_CurrentCellDirtyStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.CurrentCellDirtyStateChanged

        Select Case DataGridView1.CurrentCell.ColumnIndex
            Case 5
                ''check true if mulligan is checked
                'If DataGridView1.CurrentCell.ColumnIndex = 5 And DataGridView1.IsCurrentCellDirty = True Then
                '    Select Case DataGridView1.CurrentCell.Value
                '        Case True
                '            DataGridView1.CurrentRow.Cells(4).Value = True
                '        Case False
                '    End Select
                'End If
                DataGridView1.CurrentRow.Cells(4).Value = DataGridView1.CurrentCell.Value

            Case 4
                'uncheck mulligan if false is selected
                If DataGridView1.CurrentCell.ColumnIndex = 4 And DataGridView1.IsCurrentCellDirty = False Then
                    Select Case DataGridView1.CurrentCell.Value
                        Case False
                            DataGridView1.CurrentRow.Cells(5).Value = False
                        Case True
                    End Select
                End If
        End Select
        If DataGridView1.IsCurrentCellDirty = True Then
            UpdateScore()

        End If


    End Sub
End Class