﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTeams
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TriviaDataSet = New TriviaScoring.TriviaDataSet()
        Me.TblTeamsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblTeamsTableAdapter = New TriviaScoring.TriviaDataSetTableAdapters.tblTeamsTableAdapter()
        Me.TableAdapterManager = New TriviaScoring.TriviaDataSetTableAdapters.TableAdapterManager()
        Me.TblTeamsDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.TriviaDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTeamsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTeamsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TriviaDataSet
        '
        Me.TriviaDataSet.DataSetName = "TriviaDataSet"
        Me.TriviaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblTeamsBindingSource
        '
        Me.TblTeamsBindingSource.DataMember = "tblTeams"
        Me.TblTeamsBindingSource.DataSource = Me.TriviaDataSet
        '
        'TblTeamsTableAdapter
        '
        Me.TblTeamsTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.tblRoundsTableAdapter = Nothing
        Me.TableAdapterManager.tblScoresTableAdapter = Nothing
        Me.TableAdapterManager.tblTeamsTableAdapter = Me.TblTeamsTableAdapter
        Me.TableAdapterManager.UpdateOrder = TriviaScoring.TriviaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'TblTeamsDataGridView
        '
        Me.TblTeamsDataGridView.AutoGenerateColumns = False
        Me.TblTeamsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblTeamsDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4})
        Me.TblTeamsDataGridView.DataSource = Me.TblTeamsBindingSource
        Me.TblTeamsDataGridView.Dock = System.Windows.Forms.DockStyle.Top
        Me.TblTeamsDataGridView.Location = New System.Drawing.Point(0, 0)
        Me.TblTeamsDataGridView.Name = "TblTeamsDataGridView"
        Me.TblTeamsDataGridView.Size = New System.Drawing.Size(420, 389)
        Me.TblTeamsDataGridView.TabIndex = 1
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "UID"
        Me.DataGridViewTextBoxColumn1.HeaderText = "UID"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Visible = False
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Table_Number"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Table Number"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 75
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Team_Number"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Team Number"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 75
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Team_Name"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Team Name"
        Me.DataGridViewTextBoxColumn4.MaxInputLength = 20
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 200
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(312, 393)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(108, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "there are many teams"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'frmTeams
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(420, 413)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TblTeamsDataGridView)
        Me.Name = "frmTeams"
        Me.Text = "Teams"
        CType(Me.TriviaDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTeamsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTeamsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TriviaDataSet As TriviaScoring.TriviaDataSet
    Friend WithEvents TblTeamsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTeamsTableAdapter As TriviaScoring.TriviaDataSetTableAdapters.tblTeamsTableAdapter
    Friend WithEvents TableAdapterManager As TriviaScoring.TriviaDataSetTableAdapters.TableAdapterManager
    Friend WithEvents TblTeamsDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
