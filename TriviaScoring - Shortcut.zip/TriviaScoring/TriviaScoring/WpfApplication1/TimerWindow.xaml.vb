﻿Imports System.Data.Objects
Imports System.Windows.Threading
Imports System.Windows.Media.Animation


Class TimerWindow
    Private WithEvents m_Timer As New DispatcherTimer
    Private m_TimeLeft As Integer


    Private m_TimeInSeconds
    Private m_StartTime As DateTime
    Private m_EndTime As DateTime

    Public Property TimeInMinutes() As String
        Get
            Return m_TimeInSeconds
        End Get
        Set(ByVal value As String)
            m_TimeInSeconds = value * 60
        End Set
    End Property


    'Private Sub MainWindow_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Input.KeyEventArgs) Handles Me.KeyDown
    '    If e.Key = Key.Back Then
    '        Me.Marq.pause_marq()

    '        Select Case Me.textBlockPaused.Visibility
    '            Case Visibility.Hidden
    '                Me.textBlockPaused.Visibility = Visibility.Visible
    '            Case Visibility.Visible
    '                Me.textBlockPaused.Visibility = Visibility.Hidden
    '        End Select
    '    End If

    'End Sub

    Private Sub Window_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded

        m_Timer.Interval = TimeSpan.FromSeconds(0.5)
        AddHandler m_Timer.Tick, AddressOf DoTick
        m_TimeLeft = m_TimeInSeconds
        txtTime.Text = FormatDisplay(m_TimeLeft)
        m_StartTime = Now()
        m_Timer.Start()



    End Sub

    Private Sub DoTick(ByVal sender As Object, ByVal e As EventArgs) Handles m_Timer.Tick
        Dim m_TimeLeft As Integer = m_TimeInSeconds - (DateDiff(DateInterval.Second, m_StartTime, Now()))

        If m_TimeLeft < 1 Then
            m_Timer.Stop()
        Else
            txtTime.Text = FormatDisplay(m_TimeLeft)
        End If

    End Sub

    Function FormatDisplay(ByVal m_NumSecondsLeft As Integer) As String

        Dim m_Text As String


        Dim m_TS As TimeSpan = New TimeSpan(0, 0, m_NumSecondsLeft)
        m_Text = m_TS.Minutes.ToString("0") & ":" & m_TS.Seconds.ToString("00")


        Return m_Text
    End Function

    Private Sub TimerWindow_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Input.MouseButtonEventArgs) Handles Me.MouseDown
        Select Case e.ChangedButton
            Case MouseButton.Left
                Me.DragMove()
            Case MouseButton.Right
                Me.Close()

        End Select

    End Sub
End Class

