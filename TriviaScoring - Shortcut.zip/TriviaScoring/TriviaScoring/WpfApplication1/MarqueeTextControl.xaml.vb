﻿' ****************************************************************************
' <author>Razan Paul</author>
' <email>razanpaul@yahoo.com</email>
' <date>15.01.2010</date>
' <project>A simple Text Marquee Control in Silverlight</project>
' <web>http://weblogs.asp.net/razan</web>
' ****************************************************************************

Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Data
Imports System.Windows.Documents
Imports System.Windows.Input
Imports System.Windows.Media
Imports System.Windows.Media.Imaging
Imports System.Windows.Shapes
Imports System.Windows.Media.Animation

Namespace SilverlightMarqueeText


    ''' <summary>
    ''' Interaction logic for MarqueeText.xaml
    ''' </summary>
    Partial Public Class MarqueeText
        Inherits UserControl

        Private storyboard__1 As New Storyboard()

        Private _marqueeType As MarqueeType

        Public Property MarqueeType() As MarqueeType
            Get
                Return _marqueeType
            End Get
            Set(ByVal value As MarqueeType)
                _marqueeType = value
            End Set
        End Property

        Private _marqueeTimeInSeconds As Double

        Public Property MarqueeTimeInSeconds() As Double
            Get
                Return _marqueeTimeInSeconds
            End Get
            Set(ByVal value As Double)
                _marqueeTimeInSeconds = value
            End Set
        End Property


        Public Shared ReadOnly MarqueeContentProperty As DependencyProperty = DependencyProperty.Register("MarqueeContent", GetType(String), GetType(MarqueeText), New PropertyMetadata("", New PropertyChangedCallback(AddressOf OnTheMarqueeContentChanged)))

        Public Property MarqueeContent() As String
            Get
                Return DirectCast(GetValue(MarqueeContentProperty), String)
            End Get
            Set(ByVal value As String)
                SetValue(MarqueeContentProperty, value)
            End Set
        End Property

        Public Shared ReadOnly MarqueeHeightProperty As DependencyProperty = DependencyProperty.Register("MarqueeHeight", GetType(Double), GetType(MarqueeText), New PropertyMetadata(CDbl(10), New PropertyChangedCallback(AddressOf OnTheMarqueeHeightChanged)))

        Public Property MarqueeHeight() As Double
            Get
                Return CDbl(GetValue(MarqueeHeightProperty))
            End Get
            Set(ByVal value As Double)
                SetValue(MarqueeHeightProperty, value)
            End Set
        End Property

        Public Shared ReadOnly MarqueeWidthProperty As DependencyProperty = DependencyProperty.Register("MarqueeWidth", GetType(Double), GetType(MarqueeText), New PropertyMetadata(CDbl(10), New PropertyChangedCallback(AddressOf OnTheMarqueeWidthChanged)))

        Public Property MarqueeWidth() As Double
            Get
                Return CDbl(GetValue(MarqueeWidthProperty))
            End Get
            Set(ByVal value As Double)
                SetValue(MarqueeWidthProperty, value)
            End Set
        End Property

        Public Shared ReadOnly MarqueeBackgroundProperty As DependencyProperty = DependencyProperty.Register("MarqueeBackground", GetType(Brush), GetType(MarqueeText), New PropertyMetadata(New SolidColorBrush(Colors.Red), New PropertyChangedCallback(AddressOf OnTheMarqueeBackgroundChanged)))

        Public Property MarqueeBackground() As Brush
            Get
                Return DirectCast(GetValue(MarqueeBackgroundProperty), Brush)
            End Get
            Set(ByVal value As Brush)
                SetValue(MarqueeBackgroundProperty, value)
            End Set
        End Property

        Public Sub New()
            InitializeComponent()
            canMain.Height = Me.Height
            canMain.Width = Me.Width
            AddHandler Me.Loaded, AddressOf MarqueeText_Loaded

        End Sub
        Private Shared Sub OnTheMarqueeBackgroundChanged(ByVal sender As Object, ByVal args As DependencyPropertyChangedEventArgs)
            DirectCast(sender, MarqueeText).Background = DirectCast(args.NewValue, Brush)
            DirectCast(sender, MarqueeText).canMain.Background = DirectCast(args.NewValue, Brush)
        End Sub

        Private Shared Sub OnTheMarqueeWidthChanged(ByVal sender As Object, ByVal args As DependencyPropertyChangedEventArgs)
            DirectCast(sender, MarqueeText).Width = Convert.ToDouble(args.NewValue)
            DirectCast(sender, MarqueeText).canMain.Width = Convert.ToDouble(args.NewValue)
        End Sub

        Private Shared Sub OnTheMarqueeHeightChanged(ByVal sender As Object, ByVal args As DependencyPropertyChangedEventArgs)
            DirectCast(sender, MarqueeText).Height = Convert.ToDouble(args.NewValue)
            DirectCast(sender, MarqueeText).canMain.Height = Convert.ToDouble(args.NewValue)
        End Sub
        Private Shared Sub OnTheMarqueeContentChanged(ByVal sender As Object, ByVal args As DependencyPropertyChangedEventArgs)
            DirectCast(sender, MarqueeText).tbmarquee.Text = Convert.ToString(args.NewValue)
        End Sub

        Private Sub MarqueeText_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
            StartMarqueeing(_marqueeType)
        End Sub
        Private Sub MarqueeText_Loaded2()
            StartMarqueeing(_marqueeType)
        End Sub
        Public Sub ResetMarq()
            InitializeComponent()
            canMain.Height = 100% 'Me.Height
            canMain.Width = Me.Width
            MarqueeText_Loaded2()



        End Sub

        Public Sub StartMarqueeing(ByVal marqueeType__1 As MarqueeType)
            If marqueeType__1 = MarqueeType.LeftToRight Then
                LeftToRightMarquee()
            ElseIf marqueeType__1 = MarqueeType.RightToLeft Then
                RightToLeftMarquee()
            ElseIf marqueeType__1 = MarqueeType.TopToBottom Then
                TopToBottomMarquee()
            ElseIf marqueeType__1 = MarqueeType.BottomToTop Then
                BottomToTopMarquee()
            End If
        End Sub
        Private Sub LeftToRightMarquee()
            Dim rectangleGeometry As New RectangleGeometry()
            rectangleGeometry.Rect = New Rect(New Point(0, 0), New Size(canMain.Width, canMain.Height))
            canMain.Clip = rectangleGeometry
            Dim height As Double = canMain.Height - tbmarquee.ActualHeight
            tbmarquee.Margin = New Thickness(0, height / 2, 0, 0)
            Dim doubleAnimation As New DoubleAnimation()
            doubleAnimation.From = -tbmarquee.ActualWidth
            doubleAnimation.[To] = canMain.Width
            doubleAnimation.RepeatBehavior = RepeatBehavior.Forever
            doubleAnimation.Duration = New Duration(TimeSpan.FromSeconds(_marqueeTimeInSeconds))
            Dim storyboard__1 As New Storyboard()
            storyboard__1.Children.Add(doubleAnimation)
            Storyboard.SetTarget(doubleAnimation, tbmarquee)
            Storyboard.SetTargetProperty(doubleAnimation, New PropertyPath("(Canvas.Left)"))
            storyboard__1.Begin()
        End Sub
        Private Sub RightToLeftMarquee()
            Dim rectangleGeometry As New RectangleGeometry()
            rectangleGeometry.Rect = New Rect(New Point(0, 0), New Size(canMain.Width, canMain.Height))
            canMain.Clip = rectangleGeometry
            Dim height As Double = canMain.Height - tbmarquee.ActualHeight
            tbmarquee.Margin = New Thickness(0, height / 2, 0, 0)
            Dim doubleAnimation As New DoubleAnimation()
            doubleAnimation.From = canMain.Width
            doubleAnimation.[To] = -tbmarquee.ActualWidth
            doubleAnimation.RepeatBehavior = RepeatBehavior.Forever
            doubleAnimation.Duration = New Duration(TimeSpan.FromSeconds(_marqueeTimeInSeconds))
            Dim storyboard__1 As New Storyboard()
            storyboard__1.Children.Add(doubleAnimation)
            Storyboard.SetTarget(doubleAnimation, tbmarquee)
            Storyboard.SetTargetProperty(doubleAnimation, New PropertyPath("(Canvas.Left)"))
            storyboard__1.Begin()

        End Sub
        Private Sub TopToBottomMarquee()
            Dim rectangleGeometry As New RectangleGeometry()
            rectangleGeometry.Rect = New Rect(New Point(0, 0), New Size(canMain.Width, canMain.Height))
            canMain.Clip = rectangleGeometry
            Dim width As Double = canMain.Width - tbmarquee.ActualWidth
            tbmarquee.Margin = New Thickness(width / 2, 0, 0, 0)
            Dim doubleAnimation As New DoubleAnimation()
            doubleAnimation.From = -tbmarquee.ActualHeight
            doubleAnimation.[To] = canMain.Height
            doubleAnimation.RepeatBehavior = RepeatBehavior.Forever
            doubleAnimation.Duration = New Duration(TimeSpan.FromSeconds(_marqueeTimeInSeconds))
            Dim storyboard__1 As New Storyboard()
            storyboard__1.Children.Add(doubleAnimation)
            Storyboard.SetTarget(doubleAnimation, tbmarquee)
            Storyboard.SetTargetProperty(doubleAnimation, New PropertyPath("(Canvas.Top)"))
            storyboard__1.Begin()
        End Sub
        Private Sub BottomToTopMarquee()
            Dim rectangleGeometry As New RectangleGeometry()
            rectangleGeometry.Rect = New Rect(New Point(0, 0), New Size(canMain.Width, canMain.Height))
            canMain.Clip = rectangleGeometry
            Dim width As Double = canMain.Width '- tbmarquee.ActualWidth
            tbmarquee.Margin = New Thickness(0, 0, 0, 0)
            Dim doubleAnimation As New DoubleAnimation()
            doubleAnimation.From = canMain.Height
            doubleAnimation.[To] = -tbmarquee.ActualHeight * 20
            doubleAnimation.RepeatBehavior = RepeatBehavior.Forever
            doubleAnimation.Duration = New Duration(TimeSpan.FromSeconds(_marqueeTimeInSeconds))
            storyboard__1.Children.Add(doubleAnimation)
            Storyboard.SetTarget(doubleAnimation, tbmarquee)
            Storyboard.SetTargetProperty(doubleAnimation, New PropertyPath("(Canvas.Top)"))
            storyboard__1.Begin()
        End Sub

        Public Sub pause_marq()

            Select Case storyboard__1.GetIsPaused
                Case True
                    storyboard__1.Resume()
                Case False
                    storyboard__1.Pause()
            End Select
        End Sub

    End Class

    Public Enum MarqueeType
        LeftToRight
        RightToLeft
        TopToBottom
        BottomToTop
    End Enum
End Namespace
