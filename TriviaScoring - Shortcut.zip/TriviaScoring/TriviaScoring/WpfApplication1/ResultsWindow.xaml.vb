﻿Imports System.Data.Objects
Imports System.Windows.Threading
Imports System.Windows.Media.Animation


Class ResultsWindow
    Dim dataEntities As TriviaEntities5 = New TriviaEntities5
    Private QuestionsVS As New Collection


    Private m_Round As Integer
    Public Property LastRoundScored() As Integer
        Get
            Return m_Round
        End Get
        Set(ByVal value As Integer)
            m_Round = value
        End Set
    End Property

    Private Sub Window_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded
        Try

            Dim scores As ObjectQuery(Of vwQ) = dataEntities.vwQs
            Dim query = From q In scores
                    Select q.Question, q.Round, q.TS, q.TM
                    Where Round = m_Round

            Me.Questions.ItemsSource = query.ToList
            Me.Questions.SelectedIndex = 0

        Catch
            MsgBox(Err.Description)
        End Try

    End Sub



End Class

