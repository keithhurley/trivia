﻿Imports System.Data.Objects
Imports System.Windows.Threading
Imports System.Windows.Media.Animation


Class MainWindow
    Dim dataEntities As TriviaEntities5 = New TriviaEntities5
    Dim tmpString As String

    Private m_Round As Integer
    Public Property LastRoundScored() As Integer
        Get
            Return m_Round
        End Get
        Set(ByVal value As Integer)
            m_Round = value
        End Set
    End Property

    Private Sub MainWindow_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Input.KeyEventArgs) Handles Me.KeyDown
        Select e.Key
            Case Key.Back
                Me.Marq.pause_marq()

                Select Case Me.textBlockPaused.Visibility
                    Case Visibility.Hidden
                        Me.textBlockPaused.Visibility = Visibility.Visible
                    Case Visibility.Visible
                        Me.textBlockPaused.Visibility = Visibility.Hidden
                End Select
                'Case Key.LeftShift
                '    Me.Marq.MarqueeTimeInSeconds = Me.Marq.MarqueeTimeInSeconds - 15
                'Case Key.RightShift
                '    Me.Marq.MarqueeTimeInSeconds = Me.Marq.MarqueeTimeInSeconds + 15
        End Select


    End Sub

    Private Sub Window_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded

        Me.Marq.MarqueeHeight = Me.Height
        Me.Marq.MarqueeWidth = Me.Width

        loadScores()
    End Sub

    Public Sub loadScores()
        Try

            Dim scores As ObjectQuery(Of vwRanking1) = dataEntities.vwRanking1
            Dim query = From q In scores
                    Select q.ranking, q.Team_Name, q.Tscore, q.Tmulligan
                    Order By Tscore Descending, ranking, Team_Name

            For Each p In query

                tmpString = tmpString & CalcSpaces(25, p.Team_Name.ToString.Length, p.Team_Name)
                If p.ranking Is Nothing Then
                    tmpString = tmpString & CalcSpaces(7, 0, "")
                Else
                    tmpString = tmpString & CalcSpaces(7, p.ranking.ToString.Length, p.ranking)

                End If
                If p.Tscore Is Nothing Then
                    tmpString = tmpString & CalcSpaces(7, 1, "0")
                Else
                    tmpString = tmpString & CalcSpaces(7, p.Tscore.ToString.Length, p.Tscore)
                End If
                If p.Tmulligan Is Nothing Then
                    tmpString = tmpString & CalcSpaces(5, 1, "0")
                Else
                    tmpString = tmpString & CalcSpaces(5, p.Tmulligan.ToString.Length, p.Tmulligan)
                End If
                tmpString = tmpString & vbCrLf
            Next p

            Me.Marq.MarqueeContent = tmpString

        Catch
            MsgBox(Err.Description & vbCrLf & vbCrLf & tmpString)
        End Try


    End Sub
    Private Function CalcSpaces(ByVal Max As Integer, ByVal Used As Integer, ByVal strString As String) As String
        Dim strTmp As String
        strTmp = strString & Space(Max - Used)
        Return strTmp
    End Function

    Private Sub MainWindow_SizeChanged(ByVal sender As Object, ByVal e As System.Windows.SizeChangedEventArgs) Handles Me.SizeChanged
        'Me.Marq.ResetMarq()
    End Sub
End Class

Public Class objScore

    Public mRank As Integer
    Public Property Rank() As Integer
        Get
            Return mRank
        End Get
        Set(ByVal value As Integer)
            mRank = value
        End Set
    End Property

    Private mTeamName As String
    Public Property Team_Name() As String
        Get
            Return mTeamName
        End Get
        Set(ByVal value As String)
            mTeamName = value
        End Set
    End Property

    Private mScore As Integer
    Public Property Tscore() As Integer
        Get
            Return mScore
        End Get
        Set(ByVal value As Integer)
            mScore = value
        End Set
    End Property

    Private mMulligan As Integer
    Public Property Tmulligan() As Integer
        Get
            Return mMulligan
        End Get
        Set(ByVal value As Integer)
            mMulligan = value
        End Set
    End Property

End Class
