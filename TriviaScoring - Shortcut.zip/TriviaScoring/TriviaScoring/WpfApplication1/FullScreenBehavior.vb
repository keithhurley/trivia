﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Runtime.InteropServices
Imports System.Windows.Interactivity
Imports System.Windows
Imports System.Windows.Input
Imports System.Windows.Interop

Namespace FullScreenDemo

    ''' <summary>
    ''' A behavior that adds full-screen functionality to a window when the window is maximized,
    ''' double clicked, or the escape key is pressed.
    ''' </summary>
    Public NotInheritable Class FullScreenBehavior
        Inherits Behavior(Of Window)

#Region "Fields"

        Private hwndSource As HwndSource

#End Region

#Region "Constructors"

        ''' <summary>
        ''' Initializes a new instance of the <see cref="T:FullScreenBehavior"/> class.
        ''' </summary>
        Public Sub New()
        End Sub

#End Region

#Region "Properties"

#Region "FullScreenOnMaximize"

        ''' <summary>
        ''' Dependency property for the <see cref="P:FullScreenOnMaximize"/> property.
        ''' </summary>
        Public Shared ReadOnly FullScreenOnMaximizeProperty As DependencyProperty = DependencyProperty.Register("FullScreenOnMaximize", GetType(Boolean), GetType(FullScreenBehavior), New PropertyMetadata(False))

        ''' <summary>
        ''' Whether or not user initiated maximizing should put the window into full-screen mode.
        ''' </summary>
        Public Property FullScreenOnMaximize() As Boolean
            Get
                Return CBool(GetValue(FullScreenOnMaximizeProperty))
            End Get
            Set(ByVal value As Boolean)
                SetValue(FullScreenOnMaximizeProperty, value)
            End Set
        End Property

#End Region

#Region "FullScreenOnDoubleClick"

        ''' <summary>
        ''' Dependency property for the <see cref="P:FullScreenOnDoubleClick"/> property.
        ''' </summary>
        Public Shared ReadOnly FullScreenOnDoubleClickProperty As DependencyProperty = DependencyProperty.Register("FullScreenOnDoubleClick", GetType(Boolean), GetType(FullScreenBehavior), New PropertyMetadata(False))

        ''' <summary>
        ''' Whether or not double clicking the window's contents should put the window into full-screen mode.
        ''' </summary>
        Public Property FullScreenOnDoubleClick() As Boolean
            Get
                Return CBool(GetValue(FullScreenOnDoubleClickProperty))
            End Get
            Set(ByVal value As Boolean)
                SetValue(FullScreenOnDoubleClickProperty, value)
            End Set
        End Property

#End Region

#Region "RestoreOnEscape"

        ''' <summary>
        ''' Dependency property for the <see cref="P:RestoreOnEscape"/> property.
        ''' </summary>
        Public Shared ReadOnly RestoreOnEscapeProperty As DependencyProperty = DependencyProperty.Register("RestoreOnEscape", GetType(Boolean), GetType(FullScreenBehavior), New PropertyMetadata(False))

        ''' <summary>
        ''' Whether or not pressing escape while in full screen mode returns to windowed mode.
        ''' </summary>
        Public Property RestoreOnEscape() As Boolean
            Get
                Return CBool(GetValue(RestoreOnEscapeProperty))
            End Get
            Set(ByVal value As Boolean)
                SetValue(RestoreOnEscapeProperty, value)
            End Set
        End Property

#End Region

#Region "IsFullScreen"

        ''' <summary>
        ''' Dependency property for the <see cref="P:IsFullScreen"/> property.
        ''' </summary>
        Private Shared ReadOnly IsFullScreenProperty As DependencyProperty = DependencyProperty.RegisterAttached("IsFullScreen", GetType(Boolean), GetType(FullScreenBehavior), New PropertyMetadata(False, AddressOf OnIsFullScreenChanged))

        ''' <summary>
        ''' Gets a value indicating whether or not the specified window is currently in full-screen mode.
        ''' </summary>
        Public Shared Function GetIsFullScreen(ByVal window As Window) As Boolean
            Return CBool(window.GetValue(IsFullScreenProperty))
        End Function

        ''' <summary>
        ''' Sets a value indicating whether or not the specified window is currently in full-screen mode.
        ''' </summary>
        ''' <param name="window">The window.</param>
        ''' <param name="value">The value.</param>
        Public Shared Sub SetIsFullScreen(ByVal window As Window, ByVal value As Boolean)
            window.SetValue(IsFullScreenProperty, value)
        End Sub

        ''' <summary>
        ''' Called when the value of the IsFullScreenProperty dependency property changes.
        ''' </summary>
        ''' <param name="sender">The control instance.</param>
        ''' <param name="e">The event arguments.</param>
        Private Shared Sub OnIsFullScreenChanged(ByVal sender As DependencyObject, ByVal e As DependencyPropertyChangedEventArgs)

            Dim window = DirectCast(sender, Window)
            Dim oldValue = CBool(e.OldValue)
            Dim newValue = CBool(e.NewValue)

            If newValue <> oldValue AndAlso window IsNot Nothing Then

                If newValue Then
                    window.WindowStyle = WindowStyle.None
                    window.Topmost = True
                    window.WindowState = WindowState.Maximized
                Else
                    ' if
                    window.Topmost = False
                    window.WindowStyle = WindowStyle.SingleBorderWindow
                    window.WindowState = WindowState.Normal
                    ' else
                End If
            End If
            ' if
        End Sub

#End Region

#End Region

#Region "Methods"

        ''' <summary>
        ''' Called after the behavior is attached to an AssociatedObject.
        ''' </summary>
        ''' <remarks>Override this to hook up functionality to the AssociatedObject.</remarks>
        Protected Overrides Sub OnAttached()

            MyBase.OnAttached()

            AddHandler AssociatedObject.SourceInitialized, AddressOf Window_SourceInitialized
            AddHandler AssociatedObject.MouseDoubleClick, AddressOf Window_MouseDoubleClick
            AddHandler AssociatedObject.KeyDown, AddressOf Window_KeyDown

            AttachHook()

        End Sub

        ''' <summary>
        ''' Called when the behavior is being detached from its AssociatedObject, but before it has actually occurred.
        ''' </summary>
        ''' <remarks>Override this to unhook functionality from the AssociatedObject.</remarks>
        Protected Overrides Sub OnDetaching()

            DetachHook()

            RemoveHandler AssociatedObject.SourceInitialized, AddressOf Window_SourceInitialized
            RemoveHandler AssociatedObject.MouseDoubleClick, AddressOf Window_MouseDoubleClick
            RemoveHandler AssociatedObject.KeyDown, AddressOf Window_KeyDown

            MyBase.OnDetaching()

        End Sub

        ''' <summary>
        ''' Adds the hook procedure to the Window's HwndSource.
        ''' </summary>
        Private Sub AttachHook()
            If hwndSource Is Nothing Then
                hwndSource = DirectCast(HwndSource.FromVisual(AssociatedObject), HwndSource)
                If hwndSource IsNot Nothing Then
                    hwndSource.AddHook(AddressOf WndProc)
                    ' if
                End If
            End If
            ' if
        End Sub

        ''' <summary>
        ''' Removes the hook procedure from the Window's HwndSource.
        ''' </summary>
        Private Sub DetachHook()

            If hwndSource IsNot Nothing Then
                hwndSource.RemoveHook(AddressOf WndProc)
                hwndSource = Nothing
            End If
            ' if
        End Sub

        ''' <summary>
        ''' A hook procedure that intercepts messages sent to the attached window.
        ''' </summary>
        ''' <param name="hwnd">The window handle.</param>
        ''' <param name="msg">The message.</param>
        ''' <param name="wParam">The wParam which varies by message.</param>
        ''' <param name="lParam">The lParam which varies by message.</param>
        ''' <param name="handled">Set to true to suppress default process of this message.</param>
        ''' <returns>The return value which depends upon the message.</returns>
        Private Function WndProc(ByVal hwnd As IntPtr, ByVal msg As Integer, ByVal wParam As IntPtr, ByVal lParam As IntPtr, ByRef handled As Boolean) As IntPtr

            If msg = WM_SYSCOMMAND Then

                Dim wParam32 As Integer = wParam.ToInt32() And &HFFF0
                If wParam32 = SC_MAXIMIZE OrElse wParam32 = SC_RESTORE Then

                    If FullScreenOnMaximize Then

                        ' Cancel the default handling
                        handled = True

                        ' Go to full screen on maximize
                        ' Return from full screen on restore

                        SetIsFullScreen(AssociatedObject, (wParam32 = SC_MAXIMIZE))
                        ' if
                    End If
                    ' if
                End If
            End If
            ' if
            Return IntPtr.Zero

        End Function

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' Handles the SourceInitialized event of the Window.
        ''' </summary>
        ''' <param name="sender">The source of the event.</param>
        ''' <param name="e">The <see cref="T:EventArgs"/> instance containing the event data.</param>
        Private Sub Window_SourceInitialized(ByVal sender As Object, ByVal e As EventArgs)

            AttachHook()

        End Sub

        ''' <summary>
        ''' Handles the MouseDoubleClick event of the Window.
        ''' </summary>
        ''' <param name="sender">The source of the event.</param>
        ''' <param name="e">The <see cref="T:MouseButtonEventArgs"/> instance containing the event data.</param>
        Private Sub Window_MouseDoubleClick(ByVal sender As Object, ByVal e As MouseButtonEventArgs)

            If e.Handled = False Then

                If FullScreenOnDoubleClick Then

                    Dim current As Boolean = GetIsFullScreen(AssociatedObject)

                    SetIsFullScreen(AssociatedObject, Not current)
                    ' if
                End If
            End If
            ' if
        End Sub

        ''' <summary>
        ''' Handles the KeyDown event of the Window.
        ''' </summary>
        ''' <param name="sender">The source of the event.</param>
        ''' <param name="e">The <see cref="T:KeyEventArgs"/> instance containing the event data.</param>
        Private Sub Window_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs)

            If e.Key = Key.Escape AndAlso e.Handled = False Then

                If RestoreOnEscape Then


                    SetIsFullScreen(AssociatedObject, False)
                    ' if
                End If
            End If
            ' if
        End Sub

#End Region

#Region "Interop Stuff"

        Const WM_SYSCOMMAND As Integer = &H112
        Const SC_RESTORE As Integer = &HF120
        Const SC_MAXIMIZE As Integer = &HF030

#End Region

    End Class
    ' class
End Namespace
' namespace

