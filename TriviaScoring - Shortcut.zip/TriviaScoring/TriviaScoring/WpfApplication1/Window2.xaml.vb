﻿Imports System.Data.Objects
Imports System.Data
Imports System.Collections.ObjectModel

Public Class Window2
    Public Rankings As New ObservableCollection(Of Score)
    Dim dataEntities As TriviaEntities5 = New TriviaEntities5
    Dim tmpString As String

    Private m_Round As Integer
    Public Property LastRoundScored() As Integer
        Get
            Return m_Round
        End Get
        Set(ByVal value As Integer)
            m_Round = value
        End Set
    End Property


    Private Sub Window_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded

        loadScores()
    End Sub

    Public Sub loadScores()
        Try
            Dim scores As ObjectQuery(Of vwRanking1) = dataEntities.vwRanking1
            Dim query = From q In scores
                    Select q.ranking, q.Team_Name, q.Tscore, q.Tmulligan
                    Order By Tscore Descending, ranking, Team_Name

            For Each p In query
                Dim tmpScore As New Score
                tmpScore.TRanking = p.ranking
                tmpScore.TName = p.Team_Name
                tmpScore.TScore = p.Tscore
                tmpScore.TMulligans = p.Tmulligan
                Rankings.Add(tmpScore)
                Me.IControl.ItemsSource = Nothing
                Me.IControl.ItemsSource = Rankings

            Next p


            '    tmpString = tmpString & CalcSpaces(25, p.Team_Name.ToString.Length, p.Team_Name)
            '    If p.ranking Is Nothing Then
            '        tmpString = tmpString & CalcSpaces(7, 0, "")
            '    Else
            '        tmpString = tmpString & CalcSpaces(7, p.ranking.ToString.Length, p.ranking)

            '    End If
            '    If p.Tscore Is Nothing Then
            '        tmpString = tmpString & CalcSpaces(7, 1, "0")
            '    Else
            '        tmpString = tmpString & CalcSpaces(7, p.Tscore.ToString.Length, p.Tscore)
            '    End If
            '    If p.Tmulligan Is Nothing Then
            '        tmpString = tmpString & CalcSpaces(5, 1, "0")
            '    Else
            '        tmpString = tmpString & CalcSpaces(5, p.Tmulligan.ToString.Length, p.Tmulligan)
            '    End If
            '    'tmpString = tmpString & vbCrLf



            'Next p


        Catch
            MsgBox(Err.Description & vbCrLf & vbCrLf & tmpString)
        End Try


    End Sub
    Private Function CalcSpaces(ByVal Max As Integer, ByVal Used As Integer, ByVal strString As String) As String
        Dim strTmp As String
        strTmp = strString & Space(Max - Used)
        Return strTmp
    End Function
End Class
Public Class Score
    Private mTRanking As Integer
    Public Property TRanking() As Integer
        Get
            Return mTRanking
        End Get
        Set(ByVal value As Integer)
            mTRanking = value
        End Set
    End Property

    Private mTName As String
    Public Property TName() As String
        Get
            Return mTName
        End Get
        Set(ByVal value As String)
            mTName = value
        End Set
    End Property
    Private mTScore As Integer
    Public Property TScore() As Integer
        Get
            Return mTScore
        End Get
        Set(ByVal value As Integer)
            mTScore = value
        End Set
    End Property
    Private mTMulligans As Integer
    Public Property TMulligans() As Integer
        Get
            Return mTMulligans
        End Get
        Set(ByVal value As Integer)
            mTMulligans = value
        End Set
    End Property

End Class

