﻿update tblscores set tblscores.Correct = 0

select * from tblscores where correct=1

update tblscores set tblscores.correct=true where tblscores.teamUID = lbxTeams.SelectedValue and tblscores.Question=1 and tblscores.Round = lbxRound.selectedValue