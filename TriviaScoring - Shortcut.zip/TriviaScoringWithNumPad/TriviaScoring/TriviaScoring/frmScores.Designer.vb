﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmScores
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.TriviaDataSet = New TriviaScoring.TriviaDataSet()
        Me.TblScoresBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblScoresTableAdapter = New TriviaScoring.TriviaDataSetTableAdapters.tblScoresTableAdapter()
        Me.TableAdapterManager = New TriviaScoring.TriviaDataSetTableAdapters.TableAdapterManager()
        Me.TblTeamsTableAdapter = New TriviaScoring.TriviaDataSetTableAdapters.tblTeamsTableAdapter()
        Me.TblTeamsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Round_Number = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewCheckBoxColumn3 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.DataGridViewCheckBoxColumn4 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.lbxTeams = New System.Windows.Forms.ListBox()
        Me.lbxRounds = New System.Windows.Forms.ListBox()
        Me.TblRounds1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblRounds1TableAdapter = New TriviaScoring.TriviaDataSetTableAdapters.tblRounds1TableAdapter()
        Me.lblRoundScore = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.TriviaDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblScoresBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTeamsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblRounds1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TriviaDataSet
        '
        Me.TriviaDataSet.DataSetName = "TriviaDataSet"
        Me.TriviaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblScoresBindingSource
        '
        Me.TblScoresBindingSource.DataMember = "tblScores"
        Me.TblScoresBindingSource.DataSource = Me.TriviaDataSet
        '
        'TblScoresTableAdapter
        '
        Me.TblScoresTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.tblRoundsTableAdapter = Nothing
        Me.TableAdapterManager.tblScoresTableAdapter = Me.TblScoresTableAdapter
        Me.TableAdapterManager.tblTeamsTableAdapter = Me.TblTeamsTableAdapter
        Me.TableAdapterManager.UpdateOrder = TriviaScoring.TriviaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'TblTeamsTableAdapter
        '
        Me.TblTeamsTableAdapter.ClearBeforeFill = True
        '
        'TblTeamsBindingSource
        '
        Me.TblTeamsBindingSource.DataMember = "tblTeams"
        Me.TblTeamsBindingSource.DataSource = Me.TriviaDataSet
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.MenuBar
        Me.DataGridView1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.MenuBar
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn5, Me.Round_Number, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewCheckBoxColumn3, Me.DataGridViewCheckBoxColumn4})
        Me.DataGridView1.DataSource = Me.TblScoresBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(236, 6)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(4)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DataGridView1.RowHeadersVisible = False
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.InactiveCaption
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.DataGridView1.Size = New System.Drawing.Size(237, 466)
        Me.DataGridView1.TabIndex = 3
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "UID"
        Me.DataGridViewTextBoxColumn5.HeaderText = "UID"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Visible = False
        '
        'Round_Number
        '
        Me.Round_Number.DataPropertyName = "Round"
        Me.Round_Number.HeaderText = "Round_Number"
        Me.Round_Number.Name = "Round_Number"
        Me.Round_Number.Visible = False
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "TeamUID"
        Me.DataGridViewTextBoxColumn6.HeaderText = "TeamUID"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Visible = False
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "Question"
        Me.DataGridViewTextBoxColumn7.HeaderText = "Question"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Width = 90
        '
        'DataGridViewCheckBoxColumn3
        '
        Me.DataGridViewCheckBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.DataGridViewCheckBoxColumn3.DataPropertyName = "Correct"
        Me.DataGridViewCheckBoxColumn3.HeaderText = "Correct"
        Me.DataGridViewCheckBoxColumn3.Name = "DataGridViewCheckBoxColumn3"
        Me.DataGridViewCheckBoxColumn3.Width = 60
        '
        'DataGridViewCheckBoxColumn4
        '
        Me.DataGridViewCheckBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.DataGridViewCheckBoxColumn4.DataPropertyName = "Mulligan"
        Me.DataGridViewCheckBoxColumn4.HeaderText = "Mulligan"
        Me.DataGridViewCheckBoxColumn4.Name = "DataGridViewCheckBoxColumn4"
        Me.DataGridViewCheckBoxColumn4.Width = 66
        '
        'lbxTeams
        '
        Me.lbxTeams.DataSource = Me.TblTeamsBindingSource
        Me.lbxTeams.DisplayMember = "Team_Name"
        Me.lbxTeams.FormattingEnabled = True
        Me.lbxTeams.ItemHeight = 16
        Me.lbxTeams.Location = New System.Drawing.Point(16, 171)
        Me.lbxTeams.Margin = New System.Windows.Forms.Padding(4)
        Me.lbxTeams.Name = "lbxTeams"
        Me.lbxTeams.Size = New System.Drawing.Size(196, 340)
        Me.lbxTeams.Sorted = True
        Me.lbxTeams.TabIndex = 4
        Me.lbxTeams.ValueMember = "UID"
        '
        'lbxRounds
        '
        Me.lbxRounds.DataSource = Me.TblRounds1BindingSource
        Me.lbxRounds.DisplayMember = "Round_Number"
        Me.lbxRounds.FormattingEnabled = True
        Me.lbxRounds.ItemHeight = 16
        Me.lbxRounds.Location = New System.Drawing.Point(16, 6)
        Me.lbxRounds.Margin = New System.Windows.Forms.Padding(4)
        Me.lbxRounds.Name = "lbxRounds"
        Me.lbxRounds.Size = New System.Drawing.Size(196, 148)
        Me.lbxRounds.TabIndex = 5
        Me.lbxRounds.ValueMember = "Round_Number"
        '
        'TblRounds1BindingSource
        '
        Me.TblRounds1BindingSource.DataMember = "tblRounds1"
        Me.TblRounds1BindingSource.DataSource = Me.TriviaDataSet
        '
        'TblRounds1TableAdapter
        '
        Me.TblRounds1TableAdapter.ClearBeforeFill = True
        '
        'lblRoundScore
        '
        Me.lblRoundScore.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblRoundScore.Location = New System.Drawing.Point(232, 380)
        Me.lblRoundScore.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblRoundScore.Name = "lblRoundScore"
        Me.lblRoundScore.Size = New System.Drawing.Size(241, 32)
        Me.lblRoundScore.TabIndex = 6
        Me.lblRoundScore.Text = "Label1"
        Me.lblRoundScore.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(225, 480)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(108, 32)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "Update Score"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'frmScores
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(497, 527)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lblRoundScore)
        Me.Controls.Add(Me.lbxRounds)
        Me.Controls.Add(Me.lbxTeams)
        Me.Controls.Add(Me.DataGridView1)
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmScores"
        Me.Text = "Scores"
        CType(Me.TriviaDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblScoresBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTeamsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblRounds1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TriviaDataSet As TriviaScoring.TriviaDataSet
    Friend WithEvents TblScoresBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblScoresTableAdapter As TriviaScoring.TriviaDataSetTableAdapters.tblScoresTableAdapter
    Friend WithEvents TableAdapterManager As TriviaScoring.TriviaDataSetTableAdapters.TableAdapterManager
    Friend WithEvents TblTeamsTableAdapter As TriviaScoring.TriviaDataSetTableAdapters.tblTeamsTableAdapter
    Friend WithEvents TblTeamsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Round_Number As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn3 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn4 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents lbxTeams As System.Windows.Forms.ListBox
    Friend WithEvents lbxRounds As System.Windows.Forms.ListBox
    Friend WithEvents TblRounds1BindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblRounds1TableAdapter As TriviaScoring.TriviaDataSetTableAdapters.tblRounds1TableAdapter
    Friend WithEvents lblRoundScore As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
