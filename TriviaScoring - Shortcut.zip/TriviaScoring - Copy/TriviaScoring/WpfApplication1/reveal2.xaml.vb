﻿Public Class reveal2
    Private myTeamPlace As String
    Public Property TPlace() As String
        Get
            Return myTeamPlace
        End Get
        Set(ByVal value As String)
            myTeamPlace = value
            Me.TeamPlace.Text = value
        End Set
    End Property


    Private myTeamName As String
    Public Property TName() As String
        Get
            Return myTeamName
        End Get
        Set(ByVal value As String)
            myTeamName = value
            Me.TeamName.Text = value
        End Set

    End Property

    Private myTeamPoints As String
    Public Property TPoints() As String
        Get
            Return myTeamPoints
        End Get
        Set(ByVal value As String)
            myTeamPoints = value
            Me.TeamPoints.Text = value
        End Set
    End Property

    Public Sub ShowName()
        Me.teamPanel.Visibility = Windows.Visibility.Visible
    End Sub

    Public Sub expandPanel()
        Me.revealPanel.Visibility = Windows.Visibility.Visible
    End Sub
End Class
