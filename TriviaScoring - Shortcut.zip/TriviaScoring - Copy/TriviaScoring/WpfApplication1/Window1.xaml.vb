﻿Imports System.Data.Objects

Public Class Window1
    Dim dataEntities1 As New TriviaEntities5
    Dim RoundsClass As New List(Of clsRound)

    Private Sub Window1_Loaded(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs) Handles Me.Loaded
        Try
            'setup rounds combobox source
            Dim tmpObj As ObjectQuery(Of tblRound) = dataEntities1.tblRounds
            Dim rounds = From r In tmpObj
                         Select r.Round_Number, r.Question_Number
                         Order By Round_Number
            Dim LastX As String = ""
            For Each rec In rounds
                If rec.Round_Number <> LastX Then

                    Dim tmp As New clsRound
                    tmp.RoundNumber = rec.Round_Number
                    RoundsClass.Add(tmp)
                    LastX = rec.Round_Number
                    tmp = Nothing
                End If
            Next
            Me.cboRounds.ItemsSource = RoundsClass
        Catch
            MsgBox(Err.Description)
        End Try
        cboRounds.SelectedIndex = 0

    End Sub


    
    Private Sub cmdResultsWindow_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles cmdResultsWindow.Click
        Dim xForm As New ResultsWindow
        xForm.LastRoundScored = cboRounds.SelectedValue.ToString
        xForm.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button1.Click
        Dim xForm1 As New MainWindow
        xForm1.LastRoundScored = cboRounds.SelectedValue.ToString
        xForm1.Show()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button2.Click
        Dim xform2 As New Welcome
        xform2.Show()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button3.Click
        If IsNumeric(TextBox1.Text) Then
            Dim xform3 As New TimerWindow
            xform3.TimeInMinutes = TextBox1.Text
            xform3.Show()
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button4.Click
        Dim xform4 As New Blank
        xform4.Show()
    End Sub

    Private Sub Button5_Click(sender As Object, e As System.Windows.RoutedEventArgs) Handles Button5.Click
        Dim xform5 As New Standings
        xform5.Show()
    End Sub

    Private Sub Button6_Click(sender As Object, e As System.Windows.RoutedEventArgs) Handles Button6.Click
        Dim xform6 As New Standings2
        xform6.Show()
    End Sub
End Class

Public Class clsRound

    Private m_RoundNumber As String
    Public Property RoundNumber() As String
        Get
            Return m_RoundNumber
        End Get
        Set(ByVal value As String)
            m_RoundNumber = value
        End Set
    End Property

End Class
