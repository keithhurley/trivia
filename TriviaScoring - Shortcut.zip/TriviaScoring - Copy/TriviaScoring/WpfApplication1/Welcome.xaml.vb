﻿Imports System.Data.Objects
Imports System.Windows.Threading
Imports System.Windows.Media.Animation


Class Welcome
    Dim tmpString As String


    Private Sub MainWindow_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Input.KeyEventArgs) Handles Me.KeyDown
        If e.Key = Key.Back Then
            Me.Marq.pause_marq()

            Select Case Me.textBlockPaused.Visibility
                Case Visibility.Hidden
                    Me.textBlockPaused.Visibility = Visibility.Visible
                Case Visibility.Visible
                    Me.textBlockPaused.Visibility = Visibility.Hidden
            End Select
        End If

    End Sub

    Private Sub Window_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded

        Me.Marq.MarqueeHeight = Me.Height
        Me.Marq.MarqueeWidth = Me.Width

        loadScores()
    End Sub

    Public Sub loadScores()


        tmpString = "Have fun!" & vbCrLf & vbCrLf & _
            "All team players must be at " & vbCrLf & _
            "least 21 years old." & vbCrLf & vbCrLf & _
            "Up to two mulligans may be be " & vbCrLf & _
            "purchased 2 for 5$ BEFORE THE GAME STARTS." & vbCrLf & vbCrLf & _
            "Only one answer per question will be " & vbCrLf & _
            " allowed on the answer sheet.  Illegible " & vbCrLf & _
            "answers will be scored as wrong." & vbCrLf & vbCrLf & _
            "All cell phones must be turned off" & vbCrLf & _
            "at all times and placed in the " & vbCrLf & _
            "basket on the table." & vbCrLf & vbCrLf & _
            "Cheating will not be tolerated.  " & vbCrLf & _
            "Teams will not receive points" & vbCrLf & _
            "during that round."
        Me.Marq.MarqueeContent = tmpString


    End Sub

    Private Sub MainWindow_SizeChanged(ByVal sender As Object, ByVal e As System.Windows.SizeChangedEventArgs) Handles Me.SizeChanged
        'Me.Marq.ResetMarq()
        'Marq.MarqueeHeight = Height
        'Marq.MarqueeWidth = Me.Width - 400
        

    End Sub
End Class

