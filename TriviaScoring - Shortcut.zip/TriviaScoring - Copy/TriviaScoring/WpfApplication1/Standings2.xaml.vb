﻿Imports System.Data.Objects
Imports System.Windows.Threading
Imports System.Windows.Media.Animation


Class Standings2
    Dim dataEntities As TriviaEntities5 = New TriviaEntities5
    Dim tmpString As String

    Private m_Round As Integer
    Public Property LastRoundScored() As Integer
        Get
            Return m_Round
        End Get
        Set(ByVal value As Integer)
            m_Round = value
        End Set
    End Property

    Private Sub MainWindow_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Input.KeyEventArgs) Handles Me.KeyDown
        Select Case e.Key
            Case Key.Back

        End Select
    End Sub

    Private Sub Window_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded

        'loadScores()
    End Sub

    Public Sub loadScores()
        Try
            Dim tmp As StackPanel = Me.ListPanel


            Dim scores As ObjectQuery(Of vwRanking1) = dataEntities.vwRanking1
            Dim query = From q In scores
                    Select q.ranking, q.Team_Name, q.Tscore, q.Tmulligan
                    Order By Tscore Descending, ranking, Team_Name

            For Each p In query
                Dim newRow As New reveal2
                newRow.TPlace = p.ranking
                newRow.TName = p.Team_Name
                newRow.TPoints = p.Tscore

                tmp.Children.Add(newRow)
            Next p
            System.Windows.Forms.Application.DoEvents()
            Dim t2 As reveal2 = tmp.Children(tmp.Children.Count - 1)
            Dim curRank As Integer = t2.TPlace
            Dim toReveal As New Collection
            For intx = tmp.Children.Count - 1 To 0 Step -1
                Dim t As reveal2 = tmp.Children(intx)
                If intx = 0 Then
                    t2 = tmp.Children(0)
                Else
                    t2 = tmp.Children(intx - 1)
                End If
                t.expandPanel()
                toReveal.Add(t)
                System.Windows.Forms.Application.DoEvents()
                If t2.TPlace < curRank Or intx = 0 Then
                    System.Threading.Thread.Sleep(3000)
                    GoTo RevealAll
                Else
                    System.Threading.Thread.Sleep(500)
                    GoTo skip
                End If

RevealAll:
                For Each item In toReveal
                    System.Windows.Forms.Application.DoEvents()
                    item.ShowName()
                    System.Windows.Forms.Application.DoEvents()
                    curRank = t2.TPlace
                Next item
                toReveal.Clear()
                System.Threading.Thread.Sleep(3000)
                System.Windows.Forms.Application.DoEvents()

Skip:
            Next intx

        Catch
            MsgBox(Err.Description & vbCrLf & vbCrLf & tmpString)
        End Try


    End Sub
    Private Function CalcSpaces(ByVal Max As Integer, ByVal Used As Integer, ByVal strString As String) As String
        Dim strTmp As String
        strTmp = strString & Space(Max - Used)
        Return strTmp
    End Function


    Private Sub start_Click(sender As Object, e As System.Windows.RoutedEventArgs) Handles start.MouseUp
        loadScores()
    End Sub

    Private Sub reset_MouseUp(sender As Object, e As System.Windows.Input.MouseButtonEventArgs) Handles Reset.MouseUp
        Me.ListPanel.Children.Clear()
    End Sub
End Class

    'Public Class objScore2

    '    Public mRank As Integer
    '    Public Property Rank() As Integer
    '        Get
    '            Return mRank
    '        End Get
    '        Set(ByVal value As Integer)
    '            mRank = value
    '        End Set
    '    End Property

    '    Private mTeamName As String
    '    Public Property Team_Name() As String
    '        Get
    '            Return mTeamName
    '        End Get
    '        Set(ByVal value As String)
    '            mTeamName = value
    '        End Set
    '    End Property

    '    Private mScore As Integer
    '    Public Property Tscore() As Integer
    '        Get
    '            Return mScore
    '        End Get
    '        Set(ByVal value As Integer)
    '            mScore = value
    '        End Set
    '    End Property

    '    Private mMulligan As Integer
    '    Public Property Tmulligan() As Integer
    '        Get
    '            Return mMulligan
    '        End Get
    '        Set(ByVal value As Integer)
    '            mMulligan = value
    '        End Set
    '    End Property

'End Class

