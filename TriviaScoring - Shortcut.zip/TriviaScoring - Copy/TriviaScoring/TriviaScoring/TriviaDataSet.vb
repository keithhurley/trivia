﻿Partial Class TriviaDataSet
End Class
